package com.example.licenta;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    public EditText id;
    public Button query_button;
    public TextView result_denumire;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id=findViewById(R.id.id);
        query_button=findViewById(R.id.query_btn);
        result_denumire=findViewById(R.id.result);

        query_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseAccess databaseAccess=DatabaseAccess.getInstance(getApplicationContext());
                databaseAccess.open();

                String n=id.getText().toString();
                String denumire=databaseAccess.getDenumire(n);

                result_denumire.setText(denumire);

                databaseAccess.close();
            }
        });


    }
}