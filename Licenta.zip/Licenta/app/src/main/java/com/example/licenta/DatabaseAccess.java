package com.example.licenta;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAccess {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase db;
    private static DatabaseAccess instance;
    Cursor c= null;

    private DatabaseAccess(Context context){
        this.openHelper= new DatabaseHelper(context);
    }

    public static DatabaseAccess getInstance(Context context){
        if(instance==null){
            instance= new DatabaseAccess(context);
        }
        return instance;
    }

    //pentru deschiderea bazei de date
    public void open(){
        this.db=openHelper.getWritableDatabase();
    }

    //pentru a inchide baza de date
    public void close(){
        if(db!=null){
            this.db.close();
        }
    }

    public String getDenumire(String id){
        c=db.rawQuery("select denumire from utilizare where id='"+id+"'", new String[]{});
        StringBuffer buffer= new StringBuffer();
        while(c.moveToNext()){
            String denumire=c.getString(0);
            buffer.append(""+denumire);
        }
        return buffer.toString();
    }
//    public String getCaroserii(){
//        c=db.rawQuery("select denumire from caroserii", new String[]{});
//        StringBuffer buffer= new StringBuffer();
//        while(c.moveToNext()){
//            String denumire=c.getString(0);
//            buffer.append(""+denumire);
//        }
//        return buffer.toString();
//    }

    public List<String> getCaroserii(){
        List<String> denumiri = new ArrayList<String>();
        String selectQuery = "SELECT denumire FROM caroserii";
        Cursor cursor = db.rawQuery(selectQuery, new String[]{});

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String s=cursor.getString(0);
                denumiri.add(s);
            } while (cursor.moveToNext());
        }

        // return contact list
        return denumiri;
    }
}
