package com.example.licenta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Collections;
import java.util.List;

public class Caroserii extends AppCompatActivity {
    public RelativeLayout rel;
    public ImageView imgUser;
    public ListView lstUser;
    public ListView lstCaroserii1;
    public ListView lstCaroserii2;
    public Button btnCompara;
    public TextView txt1;
    public TextView txt2;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alege_caroseria);
        //setare imagine user
        imgUser=(ImageView)findViewById(R.id.imgUser);
        imgUser.setImageResource(R.drawable.user);
        rel=(RelativeLayout)findViewById(R.id.rel);
        lstUser=(ListView)findViewById(R.id.lstUser);
        imgUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(lstUser.getVisibility()==View.VISIBLE)
                    lstUser.setVisibility(View.INVISIBLE);
                else
                    lstUser.setVisibility(View.VISIBLE);
            }
        });

        //preluarea caroseriilor din baza de date
        DatabaseAccess databaseAccess=DatabaseAccess.getInstance(getApplicationContext());
        databaseAccess.open();

        lstCaroserii1=(ListView)findViewById(R.id.lstCaroserii1);
        lstCaroserii2=(ListView)findViewById(R.id.lstCaroserii2);
        List<String> s=databaseAccess.getCaroserii();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.m,R.id.textView, s);
        lstCaroserii1.setAdapter(arrayAdapter);
        lstCaroserii2.setAdapter(arrayAdapter);
        lstUser.setAdapter(arrayAdapter);
        databaseAccess.close();

        //la click pe numele caroseriei, se va adauga in text view-ul aferent listei numele caroseriei
        txt1=findViewById(R.id.car1);
        txt2=findViewById(R.id.car2);
        lstCaroserii1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                txt1.setText(lstCaroserii1.getItemAtPosition(position).toString());
            }
        });
        lstCaroserii2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                txt2.setText(lstCaroserii2.getItemAtPosition(position).toString());
            }
        });

        //butonul Compara va trimite utilizatorul spre pagina comparatie
        btnCompara=(Button)findViewById(R.id.btnCompara);
        btnCompara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Caroserii.this, Comparatie.class));
            }
        });
   }
}